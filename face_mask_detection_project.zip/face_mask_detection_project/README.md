
# Face Mask Detection Using CNN and OpenCV

## Project Overview
This project aims to detect whether a person is wearing a face mask using computer vision and deep learning techniques. It uses TensorFlow/Keras for model training and OpenCV for real-time detection from webcam or images.

## Directory Structure
```
face_mask_detection_project/
├── app/                # Streamlit web app for demo
├── dataset/            # Dataset directory (Put 'with_mask' and 'without_mask' subfolders here)
├── models/             # Trained model files
├── notebooks/          # Jupyter notebooks for EDA and experimentation
├── src/                # Training and evaluation scripts
├── requirements.txt
└── README.md
```

## Setup Instructions
```bash
# Create virtual environment (recommended)
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## Usage

### Train the Model
```bash
python src/train_model.py --dataset dataset --model_path models/mask_detector.h5
```

### Evaluate the Model
```bash
python src/evaluate_model.py --model_path models/mask_detector.h5
```

### Run the Streamlit App
```bash
streamlit run app/app.py
```

## Real-World Application
This system can be used in public places like airports, hospitals, and stations to ensure compliance with health regulations during pandemics or outbreaks.
