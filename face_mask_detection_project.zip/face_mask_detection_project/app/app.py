
import streamlit as st
import numpy as np
import cv2
import tensorflow as tf
from PIL import Image

st.set_page_config(page_title="Face Mask Detector", layout="centered")
st.title("😷 Face Mask Detection")

model = tf.keras.models.load_model("models/mask_detector.h5")

uploaded = st.file_uploader("Upload a Face Image", type=["jpg", "jpeg", "png"])

if uploaded:
    img = Image.open(uploaded)
    img = img.convert("RGB")
    img_array = np.array(img)
    resized = cv2.resize(img_array, (224, 224))
    img_input = np.expand_dims(resized, axis=0) / 255.0
    prediction = model.predict(img_input)
    label = "With Mask" if np.argmax(prediction) == 0 else "Without Mask"
    confidence = np.max(prediction) * 100
    st.image(img, caption=f"Prediction: {label} ({confidence:.2f}%)", use_column_width=True)
